## How to use
Launch server application first.
```
$ npm install
$ node app.js
```